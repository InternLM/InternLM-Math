Please note:
- All models are runned with tp_degree=1. 


